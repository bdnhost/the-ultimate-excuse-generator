<?php
// Copy this file to config.php and add your API key
define('GEMINI_API_KEY', 'YOUR_API_KEY_HERE');
