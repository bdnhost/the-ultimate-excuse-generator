<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); echo json_encode(['error' => 'Method not allowed']); exit; }

$configFile = __DIR__ . '/config.php';
if (!file_exists($configFile)) { http_response_code(500); echo json_encode(['error' => 'Config not found']); exit; }
require_once $configFile;
if (!defined('GEMINI_API_KEY') || empty(GEMINI_API_KEY)) { http_response_code(500); echo json_encode(['error' => 'API key not configured']); exit; }

$input = file_get_contents('php://input');
$data = json_decode($input, true);
$petType = $data['petType'] ?? 'כלב';
$personality = $data['personality'] ?? 'חמוד';

$prompt = "אתה מומחה לשמות של חיות מחמד. צור 3 שמות יצירתיים ומקוריים בעברית עבור {$petType} עם אופי {$personality}.

הנחיות:
1. שמות קצרים וקליטים (1-2 מילים)
2. שמות מתאימים לילדים
3. תן משמעות לכל שם
4. הוסף כינוי חמוד לכל שם
5. הכל בעברית";

$apiKey = GEMINI_API_KEY;
$apiUrl = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key={$apiKey}";

$responseSchema = [
    'type' => 'object',
    'properties' => [
        'names' => [
            'type' => 'array',
            'items' => [
                'type' => 'object',
                'properties' => [
                    'name' => ['type' => 'string'],
                    'meaning' => ['type' => 'string'],
                    'nickname' => ['type' => 'string'],
                    'emoji' => ['type' => 'string']
                ],
                'required' => ['name', 'meaning', 'nickname', 'emoji']
            ]
        ]
    ],
    'required' => ['names']
];

$payload = [
    'contents' => [['parts' => [['text' => $prompt]]]],
    'generationConfig' => [
        'responseMimeType' => 'application/json',
        'responseSchema' => $responseSchema,
        'temperature' => 1.0
    ]
];

$ch = curl_init($apiUrl);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => json_encode($payload),
    CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
    CURLOPT_TIMEOUT => 30
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($httpCode !== 200) { http_response_code($httpCode); echo json_encode(['error' => 'AI service error']); exit; }

$responseData = json_decode($response, true);
if (!isset($responseData['candidates'][0]['content']['parts'][0]['text'])) {
    http_response_code(500); echo json_encode(['error' => 'Invalid response']); exit;
}

echo $responseData['candidates'][0]['content']['parts'][0]['text'];
